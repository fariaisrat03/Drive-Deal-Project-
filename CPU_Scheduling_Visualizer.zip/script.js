const demo = [
  {id:"P1", at:0, bt:5, priority:2},
  {id:"P2", at:1, bt:3, priority:1},
  {id:"P3", at:2, bt:8, priority:3},
  {id:"P4", at:3, bt:2, priority:4}
];

const names = {
  FCFS:"FCFS",
  SJF:"SJF (Non-Preemptive)",
  SRTF:"SRTF (Preemptive)",
  PRIORITY:"Priority (Non-Preemptive)",
  PRIORITY_PREEMPTIVE:"Priority (Preemptive)",
  RR:"Round Robin"
};

const $ = id => document.getElementById(id);

function addRow(tbodyId, p={id:"",at:0,bt:1,priority:1}) {
  const tr=document.createElement("tr");
  tr.innerHTML=`
    <td><input class="pid" value="${p.id}"></td>
    <td><input class="at" type="number" min="0" value="${p.at}"></td>
    <td><input class="bt" type="number" min="1" value="${p.bt}"></td>
    <td><input class="priority" type="number" min="1" value="${p.priority}"></td>
    <td><button class="remove-btn">Remove</button></td>`;
  tr.querySelector(".remove-btn").onclick=()=>tr.remove();
  $(tbodyId).appendChild(tr);
}

function fillTable(tbodyId, data) {
  $(tbodyId).innerHTML="";
  data.forEach(p=>addRow(tbodyId,p));
}

function readTable(tbodyId) {
  const rows=[...$(tbodyId).querySelectorAll("tr")];
  if(!rows.length) throw new Error("Please add at least one process.");
  const data=rows.map((r,i)=>({
    id:r.querySelector(".pid").value.trim() || `P${i+1}`,
    at:Number(r.querySelector(".at").value),
    bt:Number(r.querySelector(".bt").value),
    priority:Number(r.querySelector(".priority").value)
  }));
  if(data.some(p=>!Number.isFinite(p.at)||p.at<0||!Number.isFinite(p.bt)||p.bt<=0||!Number.isFinite(p.priority)||p.priority<1))
    throw new Error("Arrival time must be 0 or more, burst time must be greater than 0, and priority must be at least 1.");
  const ids=data.map(p=>p.id);
  if(new Set(ids).size!==ids.length) throw new Error("Process IDs must be unique.");
  return data;
}

function pushSegment(segments,id,start,end){
  if(end<=start) return;
  const last=segments[segments.length-1];
  if(last && last.id===id && last.end===start) last.end=end;
  else segments.push({id,start,end});
}

function finalize(processes,segments){
  const map=new Map(processes.map(p=>[p.id,{...p}]));
  for(const p of processes){
    const segs=segments.filter(s=>s.id===p.id);
    p.ct=segs.length?segs[segs.length-1].end:p.at;
    p.tat=p.ct-p.at;
    p.wt=p.tat-p.bt;
  }
  const start=Math.min(...segments.map(s=>s.start),...processes.map(p=>p.at));
  const end=Math.max(...segments.map(s=>s.end),...processes.map(p=>p.at));
  const busy=segments.filter(s=>s.id!=="IDLE").reduce((a,s)=>a+s.end-s.start,0);
  const idle=Math.max(0,(end-start)-busy);
  const avgWT=processes.reduce((a,p)=>a+p.wt,0)/processes.length;
  const avgTAT=processes.reduce((a,p)=>a+p.tat,0)/processes.length;
  const utilization=(end-start)>0?(busy/(end-start))*100:0;
  return {processes,segments,start,end,idle,avgWT,avgTAT,utilization};
}

function fcfs(input){
  const ps=input.map(p=>({...p})).sort((a,b)=>a.at-b.at||a.id.localeCompare(b.id));
  const seg=[]; let t=0;
  for(const p of ps){
    if(t<p.at){pushSegment(seg,"IDLE",t,p.at);t=p.at;}
    pushSegment(seg,p.id,t,t+p.bt);t+=p.bt;
  }
  return finalize(input.map(p=>({...p})),seg);
}

function sjf(input){
  const ps=input.map(p=>({...p})); const seg=[]; let t=0,done=new Set();
  while(done.size<ps.length){
    const available=ps.filter(p=>!done.has(p.id)&&p.at<=t);
    if(!available.length){
      const next=Math.min(...ps.filter(p=>!done.has(p.id)).map(p=>p.at));
      pushSegment(seg,"IDLE",t,next);t=next;continue;
    }
    available.sort((a,b)=>a.bt-b.bt||a.at-b.at||a.id.localeCompare(b.id));
    const p=available[0]; pushSegment(seg,p.id,t,t+p.bt);t+=p.bt;done.add(p.id);
  }
  return finalize(ps,seg);
}

function srtf(input){
  const ps=input.map(p=>({...p,remaining:p.bt})); const seg=[]; let t=0,finished=0;
  while(finished<ps.length){
    const avail=ps.filter(p=>p.remaining>0&&p.at<=t);
    if(!avail.length){
      const next=Math.min(...ps.filter(p=>p.remaining>0).map(p=>p.at));
      pushSegment(seg,"IDLE",t,next);t=next;continue;
    }
    avail.sort((a,b)=>a.remaining-b.remaining||a.at-b.at||a.id.localeCompare(b.id));
    const p=avail[0]; const nextArrival=Math.min(...ps.filter(x=>x.remaining>0&&x.at>t).map(x=>x.at),Infinity);
    const run=Math.min(p.remaining,nextArrival-t);
    pushSegment(seg,p.id,t,t+run);p.remaining-=run;t+=run;
    if(p.remaining===0) finished++;
  }
  return finalize(ps.map(({remaining,...p})=>p),seg);
}

function priority(input,preemptive=false){
  const ps=input.map(p=>({...p,remaining:p.bt})); const seg=[]; let t=0,finished=0;
  while(finished<ps.length){
    const avail=ps.filter(p=>p.remaining>0&&p.at<=t);
    if(!avail.length){
      const next=Math.min(...ps.filter(p=>p.remaining>0).map(p=>p.at));
      pushSegment(seg,"IDLE",t,next);t=next;continue;
    }
    avail.sort((a,b)=>a.priority-b.priority||a.at-b.at||a.id.localeCompare(b.id));
    const p=avail[0];
    if(preemptive){
      const nextArrival=Math.min(...ps.filter(x=>x.remaining>0&&x.at>t).map(x=>x.at),Infinity);
      const run=Math.min(p.remaining,nextArrival-t);
      pushSegment(seg,p.id,t,t+run);p.remaining-=run;t+=run;
    }else{
      pushSegment(seg,p.id,t,t+p.remaining);t+=p.remaining;p.remaining=0;
    }
    if(p.remaining===0) finished++;
  }
  return finalize(ps.map(({remaining,...p})=>p),seg);
}

function rr(input,quantum){
  const ps=input.map(p=>({...p,remaining:p.bt})); const seg=[];
  const order=ps.slice().sort((a,b)=>a.at-b.at||a.id.localeCompare(b.id));
  let t=0,idx=0,finished=0; const q=[];
  while(finished<ps.length){
    while(idx<order.length&&order[idx].at<=t) q.push(order[idx++]);
    if(!q.length){
      if(idx<order.length){pushSegment(seg,"IDLE",t,order[idx].at);t=order[idx].at;continue;}
    }
    const p=q.shift(); const run=Math.min(quantum,p.remaining);
    pushSegment(seg,p.id,t,t+run);p.remaining-=run;t+=run;
    while(idx<order.length&&order[idx].at<=t) q.push(order[idx++]);
    if(p.remaining>0) q.push(p); else finished++;
  }
  return finalize(ps.map(({remaining,...p})=>p),seg);
}

function runAlgorithm(input,alg,q=2){
  if(alg==="FCFS") return fcfs(input);
  if(alg==="SJF") return sjf(input);
  if(alg==="SRTF") return srtf(input);
  if(alg==="PRIORITY") return priority(input,false);
  if(alg==="PRIORITY_PREEMPTIVE") return priority(input,true);
  if(alg==="RR") return rr(input,q);
}

function renderGantt(target,result){
  target.innerHTML="";
  const total=Math.max(1,result.end-result.start);
  result.segments.forEach((s,i)=>{
    const d=document.createElement("div");
    d.className="gantt-item"+(s.id==="IDLE"?" idle":"");
    d.style.setProperty("--duration",(s.end-s.start)/total);
    d.innerHTML=`${s.id}<span class="gantt-time">${s.start}</span>${i===result.segments.length-1?`<span class="gantt-end">${s.end}</span>`:""}`;
    target.appendChild(d);
  });
}

function showResult(result,alg){
  $("visualResults").classList.remove("hidden");
  $("algorithmBadge").textContent=names[alg];
  $("avgWT").textContent=result.avgWT.toFixed(2);
  $("avgTAT").textContent=result.avgTAT.toFixed(2);
  $("idleTime").textContent=result.idle.toFixed(2);
  $("utilization").textContent=result.utilization.toFixed(2)+"%";
  renderGantt($("gantt"),result);
  const tbody=$("resultTable").querySelector("tbody");tbody.innerHTML="";
  result.processes.sort((a,b)=>a.id.localeCompare(b.id,undefined,{numeric:true})).forEach(p=>{
    const tr=document.createElement("tr");
    tr.innerHTML=`<td><b>${p.id}</b></td><td>${p.at}</td><td>${p.bt}</td><td>${p.ct}</td><td>${p.tat}</td><td>${p.wt}</td>`;
    tbody.appendChild(tr);
  });
}

function renderComparison(results){
  $("compareResults").classList.remove("hidden");
  const tbody=$("compareTable").querySelector("tbody");tbody.innerHTML="";
  results.forEach(r=>{
    const tr=document.createElement("tr");
    tr.innerHTML=`<td><b>${names[r.alg]}</b></td><td>${r.result.avgWT.toFixed(2)}</td><td>${r.result.avgTAT.toFixed(2)}</td><td>${r.result.idle.toFixed(2)}</td><td>${r.result.utilization.toFixed(2)}%</td>`;
    tbody.appendChild(tr);
  });
  const charts=$("compareCharts");charts.innerHTML="";
  results.forEach(r=>{
    const card=document.createElement("div");card.className="card compare-block";
    card.innerHTML=`<div class="card-head"><h3>${names[r.alg]}</h3><span class="metric-pill">Gantt Chart</span></div><div class="gantt"></div>`;
    charts.appendChild(card);renderGantt(card.querySelector(".gantt"),r.result);
  });
}

function setupTable(tbodyId,data){fillTable(tbodyId,data)}

function alertError(e){alert(e.message||e)}

$("algorithm").addEventListener("change",e=>$("quantumWrap").classList.toggle("hidden",e.target.value!=="RR"));

$("generate").onclick=()=>{
  try{
    const input=readTable("processTable"), alg=$("algorithm").value, q=Number($("quantum").value);
    if(alg==="RR"&&q<1) throw new Error("Time quantum must be greater than 0.");
    showResult(runAlgorithm(input,alg,q),alg);
    $("inputStatus").textContent="Generated";
    $("visualResults").scrollIntoView({behavior:"smooth",block:"start"});
  }catch(e){alertError(e)}
};

$("addProcess").onclick=()=>addRow("processTable",{id:`P${$("processTable").children.length+1}`,at:0,bt:1,priority:1});
$("clearProcesses").onclick=()=>{$("processTable").innerHTML="";addRow("processTable",{id:"P1",at:0,bt:5,priority:2})};
$("loadDemo").onclick=()=>{fillTable("processTable",demo);$("algorithm").value="FCFS";$("quantumWrap").classList.add("hidden")};

$("addCompareProcess").onclick=()=>addRow("compareProcessTable",{id:`P${$("compareProcessTable").children.length+1}`,at:0,bt:1,priority:1});
$("clearCompareProcesses").onclick=()=>{$("compareProcessTable").innerHTML="";addRow("compareProcessTable",{id:"P1",at:0,bt:5,priority:2})};
$("compareDemo").onclick=()=>fillTable("compareProcessTable",demo);

$("compareBtn").onclick=()=>{
  try{
    const input=readTable("compareProcessTable");
    const algorithms=[...document.querySelectorAll('#compare .algorithm-grid input:checked')].map(x=>x.value);
    if(algorithms.length<2) throw new Error("Please select at least two algorithms.");
    const q=Number($("compareQuantum").value);
    if(algorithms.includes("RR")&&q<1) throw new Error("Round Robin time quantum must be greater than 0.");
    renderComparison(algorithms.map(alg=>({alg,result:runAlgorithm(input,alg,q)})));
    $("compareResults").scrollIntoView({behavior:"smooth",block:"start"});
  }catch(e){alertError(e)}
};

document.querySelectorAll(".nav-btn").forEach(btn=>{
  btn.onclick=()=>{
    document.querySelectorAll(".nav-btn").forEach(x=>x.classList.remove("active"));
    document.querySelectorAll(".page").forEach(x=>x.classList.remove("active"));
    btn.classList.add("active");$(btn.dataset.page).classList.add("active");
    window.scrollTo({top:0,behavior:"smooth"});
  };
});

fillTable("processTable",demo);
fillTable("compareProcessTable",demo);
